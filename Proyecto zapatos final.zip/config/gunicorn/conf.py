name = 'proyecto'
loglevel = 'info'
errorlog = '-'
acceslog = '-'
workers = 2